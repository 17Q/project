'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/17q/project/master/builds/builds.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notification File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/17q/project/master/builds/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'http://CHANGEME/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
