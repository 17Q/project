# script.extendedinfo
MetaInfo Kodi Add-on
