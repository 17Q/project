# script.extendedinfo
MetaInfo Kodi Add-on fork of OpenInfo
