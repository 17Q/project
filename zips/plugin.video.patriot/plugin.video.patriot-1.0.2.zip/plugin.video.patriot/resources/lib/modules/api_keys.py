# -*- coding: utf-8 -*-

'''
    Patriot Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


tmdb_key = '6e6a68c545dffdce0e054d1060fdd6e0'
tvdb_key = 'CAC2F74D9CB97149'
fanarttv_key = 'e2355ed4187bb206b3b87152073333aa'
yt_key = 'AIzaSyAO7xj2i30yaJorW2xrXybx7f1CVScmNB8'
trakt_client_id = 'f1bbcd43412a8e479a4f00061c285cb68b879f4d108474e7e5b70f165a34189a'
trakt_secret = 'e3a56b231928be7662a2d7e165e0ac4d93f2ca423c637e75aaaaa5589c000795'
orion_key = 'JFLMB6G2RFMFJFSNT7HEJLANMEFL8TJM'
